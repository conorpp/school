/*
    Just about all microcontrollers have timer subsystems otherwise you cant do crap
    
    
*/