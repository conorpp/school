/* 
 * File:   main.c
 * Author: Conor Patrick
 *
 * This code meets the requirements for the assignment.
 * 
 * Created on February 16, 2014, 3:56 PM
 */
#include <plib.h>
#include "PmodOLED.h"
#include "OledChar.h"
#include "OledGrph.h"
#include "delay.h"

// Digilent board configuration
#pragma config ICESEL       = ICS_PGx1  // ICE/ICD Comm Channel Select
#pragma config DEBUG        = OFF       // Debugger Disabled for Starter Kit

#pragma config FNOSC        = PRIPLL	// Oscillator selection
#pragma config POSCMOD      = XT	// Primary oscillator mode
#pragma config FPLLIDIV     = DIV_2	// PLL input divider
#pragma config FPLLMUL      = MUL_20	// PLL multiplier
#pragma config FPLLODIV     = DIV_1	// PLL output divider
#pragma config FPBDIV       = DIV_8	// Peripheral bus clock divider
#pragma config FSOSCEN      = OFF	// Secondary oscillator enable

#define GetPGClock() 10000000

typedef char state;

void myDisplayOnOLED(char *str);
void openMyUart(UART_MODULE theUART);
void wowBestCourse(UART_MODULE theUART);
void beginMyOled();
int checkState(char new);


int main() {
    // start OLED and UART
    beginMyOled();
    openMyUart(UART1);
    
    char buf[17] = "                ";
    
   
    while(1){
        // read uart if data is there
        if ( !UARTReceivedDataIsAvailable(UART1) ) continue;
        buf[0] = UARTGetDataByte(UART1);

        // display the data on the OLED
        myDisplayOnOLED(buf);

        // update the state machine with the data.
        if ( checkState(buf[0]) ) continue;

        // echo data by default
        UARTSendDataByte(UART1, '\n');
        UARTSendDataByte(UART1, '\r');
        UARTSendDataByte(UART1, buf[0]);

        
    }
    return (EXIT_SUCCESS);
}


/*
    Displays a message on the OLED
 */
void myDisplayOnOLED(char *str){
    if (!*str) return;
    OledSetCursor(0, 2);
    OledPutString(str);
}

/*
    Opens a uart with the general settings
 */
void openMyUart(UART_MODULE theUART){
    UARTConfigure( theUART, UART_ENABLE_PINS_TX_RX_ONLY );
    UARTSetDataRate(theUART, GetPGClock(), 9600);
    UARTEnable( theUART, UART_ENABLE|UART_PERIPHERAL|UART_RX|UART_TX );
}


/*
    Echos a respectful message through a uart
 */
void wowBestCourse(UART_MODULE theUART){
    char *str = "\n\r2534 is the best course in the curriculum\n\r";
    while(*str != '\0'){
        while(!UARTTransmissionHasCompleted(theUART));
        UARTSendDataByte(theUART, *str);
        str++;
    }
};
/*
    Initializes the OLED for debugging purposes
*/
void beginMyOled(){
   DelayInit();
   OledInit();

   OledSetCursor(0, 0);
   OledClearBuffer();
   OledPutString("Conor Patrick");
   OledUpdate();
}


/*
     checks the state of machine with character.
     will output respectful message if state correctly reaches 2534
 */
static state commState = 0;
int checkState(char new){
    switch(new){
        case '2':
            if (commState == '2') {
                commState = 0;
                break;
            }
            commState = new;
        break;
        case '5':
            if (commState != '2') break;
            commState = new;
        break;
        case '3':
            if (commState != '5') break;
            commState = new;
        break;
        case '4':
            if (commState != '3') break;
            wowBestCourse(UART1);               //computer
            myDisplayOnOLED("BEST COURSE!");    // OLED
            return 1;
        break;
        default:
            
        break;
    }

    return 0;
}